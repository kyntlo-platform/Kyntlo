# Kyntlo Academy — YouTube upload guide

Create one playlist per module, upload lessons in order, and add every video to the full-course playlist too.
For each video: title, description (includes chapters), the `.srt` as English captions, the `.thumbnail.png` as thumbnail (custom thumbnails need a verified channel: youtube.com/verify).

Full-course playlist: **Kyntlo Academy — Complete Course** (75 lessons, 226 minutes)

## Playlist: Kyntlo Academy · Module 1 — Getting Started

### 1.1 · Welcome to Kyntlo: the platform, the packages & which plan fits you (4:58)

**Title:** Lesson 1/75 · Welcome to Kyntlo & Its 4 Plans | Kyntlo Course – Module 1: Getting Started

**Description:**

```
📚 Kyntlo Course · Lesson 1 of 75 · Module 1 of 15: Getting Started

Start here. What Kyntlo is, a quick tour of everything inside it, the four Kyntlo packages (Starter, Growth, Pro and Customized), how billing works, and how to choose the right plan for your business.

Chapters:
0:00 Welcome
0:14 The problem Kyntlo solves
0:34 What is Kyntlo?
0:50 A quick tour
1:04 Every tool, one sidebar
1:21 Pipelines, sites & marketing
1:37 Automation, AI & reviews
1:53 The four packages
2:08 Starter
2:31 Growth
2:54 Pro
3:20 Customized
3:39 Billing & usage
4:00 Which plan fits you?
4:19 Free trial & upgrades
4:32 How this course works

◀ Previous: Course trailer
▶ Next: Lesson 2 · Logging In & Interface Tour
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Kyntlopricing #CRMforsmallbusiness #Gettingstarted
```

### 1.2 · Logging in & the Kyntlo interface tour (3:00)

**Title:** Lesson 2/75 · Logging In & Interface Tour | Kyntlo Course – Module 1: Getting Started

**Description:**

```
📚 Kyntlo Course · Lesson 2 of 75 · Module 1 of 15: Getting Started

Find your way around Kyntlo in a few minutes: logging in, the account switcher, search, the sidebar, module tabs, the top bar, Ask AI, notifications and Settings.

Chapters:
0:00 Intro
0:12 Logging in
0:27 The dashboard
0:40 Account switcher
0:55 Search
1:07 The sidebar
1:25 Module tabs
1:39 Conversations, calendars & opportunities
1:55 The top bar
2:11 Ask AI
2:23 Launchpad & Settings
2:41 Pro tip

◀ Previous: Lesson 1 · Welcome to Kyntlo & Its 4 Plans
▶ Next: Lesson 3 · Launchpad: First-Day Setup
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMtutorial #Gettingstarted
```

### 1.3 · Your Launchpad: first-day setup checklist (2:46)

**Title:** Lesson 3/75 · Launchpad: First-Day Setup | Kyntlo Course – Module 1: Getting Started

**Description:**

```
📚 Kyntlo Course · Lesson 3 of 75 · Module 1 of 15: Getting Started

Work through the Launchpad checklist: connect your Google Business Profile and Facebook & Instagram, install the website chat widget, and set up your email and phone, so your account is ready to capture leads on day one.

Chapters:
0:00 Intro
0:13 What Launchpad is
0:25 Google Business Profile
0:50 Facebook & Instagram
1:09 Chat widget
1:39 Email
1:57 Phone number
2:14 Your progress
2:24 Pro tip

◀ Previous: Lesson 2 · Logging In & Interface Tour
▶ Next: Lesson 4 · Business Profile & Branding
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Gettingstarted #Launchpad #GoogleBusinessProfile #Chatwidget
```

### 1.4 · Business profile & branding (3:03)

**Title:** Lesson 4/75 · Business Profile & Branding | Kyntlo Course – Module 1: Getting Started

**Description:**

```
📚 Kyntlo Course · Lesson 4 of 75 · Module 1 of 15: Getting Started

Set up your Business Profile in Kyntlo: upload your logo, add your business details and address, choose the right time zone, and fill in the legal and compliance information used for phone and messaging registration.

Chapters:
0:00 Intro
0:12 Finding Business Profile
0:27 Logo
0:43 Business details
1:11 Address & time zone
1:42 Legal & compliance
1:59 Authorized representative
2:10 General settings
2:25 My Profile
2:37 Pro tip

◀ Previous: Lesson 3 · Launchpad: First-Day Setup
▶ Next: Lesson 5 · Invite Your Team & Permissions
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Gettingstarted #Businessprofile #Settings
```

### 1.5 · Inviting your team & user permissions (2:43)

**Title:** Lesson 5/75 · Invite Your Team & Permissions | Kyntlo Course – Module 1: Getting Started

**Description:**

```
📚 Kyntlo Course · Lesson 5 of 75 · Module 1 of 15: Getting Started

Add team members in Settings → My Staff, choose their permissions and role, limit them to their own contacts, set their phone number, and assign them to booking calendars.

Chapters:
0:00 Intro
0:11 My Staff
0:29 Add an employee
0:40 Permissions
1:11 Roles
1:28 Call settings
1:38 The invitation
1:57 Calendar assignment
2:20 Pro tip

◀ Previous: Lesson 4 · Business Profile & Branding
▶ Next: Lesson 6 · Reading Your Dashboard
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Gettingstarted #Team #Userpermissions
```

## Playlist: Kyntlo Academy · Module 2 — Dashboard & Reporting

### 2.1 · Reading your dashboard (2:57)

**Title:** Lesson 6/75 · Reading Your Dashboard | Kyntlo Course – Module 2: Dashboard & Reports

**Description:**

```
📚 Kyntlo Course · Lesson 6 of 75 · Module 2 of 15: Dashboard & Reports

Understand every part of your Kyntlo dashboard: navigation, dashboards and date ranges, opportunity status, opportunity value, conversion rate, the funnel and stage distribution, and per-widget pipeline filters.

Chapters:
0:00 Intro
0:12 Your home screen
0:24 Where the numbers come from
0:34 Finding your way around
0:46 The sidebar
1:02 Dashboards & date range
1:15 Opportunity status
1:27 Opportunity value
1:43 Conversion rate
1:58 Funnel & stages
2:10 Filtering a widget
2:23 Ask AI
2:33 Pro tip

◀ Previous: Lesson 5 · Invite Your Team & Permissions
▶ Next: Lesson 7 · Customising Dashboards
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMdashboard #Salesreporting
```

### 2.2 · Customising dashboards (3:11)

**Title:** Lesson 7/75 · Customising Dashboards | Kyntlo Course – Module 2: Dashboard & Reports

**Description:**

```
📚 Kyntlo Course · Lesson 7 of 75 · Module 2 of 15: Dashboard & Reports

Make the dashboard your own: edit mode, resizing and rearranging widgets, widget settings, adding widgets, and building a separate dashboard for each role in your team.

Chapters:
0:00 Intro
0:12 Why customise
0:28 Edit mode
0:41 Resize a widget
0:52 Rearrange widgets
1:05 Widget settings
1:18 Add a widget
1:32 Save your changes
1:49 A dashboard per role
2:00 Build it
2:11 Switching dashboards
2:24 Ideas for each role
2:44 Pro tip

◀ Previous: Lesson 6 · Reading Your Dashboard
▶ Next: Lesson 8 · Google & Facebook Ads Reporting
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMdashboard #Customdashboards
```

### 2.3 · Google & Facebook ads reporting (3:17)

**Title:** Lesson 8/75 · Google & Facebook Ads Reporting | Kyntlo Course – Module 2: Dashboard & Reports

**Description:**

```
📚 Kyntlo Course · Lesson 8 of 75 · Module 2 of 15: Dashboard & Reports

Connect your Google Ads and Facebook ad accounts, read clicks, cost and cost per lead, and use the Attribution Report to see which sources actually bring in leads and revenue.

Chapters:
0:00 Intro
0:13 Where ads reporting lives
0:28 Connect Google Ads
0:41 Reading the Google report
0:56 Cost per conversion
1:11 Campaigns & keywords
1:25 Facebook Ads
1:39 Facebook campaigns
1:54 Attribution report
2:09 Sources & campaigns
2:21 First vs last attribution
2:37 Making decisions
2:51 Pro tip

◀ Previous: Lesson 7 · Customising Dashboards
▶ Next: Lesson 9 · Call, Appointment & Agent Reports
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #GoogleAds #FacebookAds #Attribution
```

### 2.4 · Call, appointment & agent reports (3:03)

**Title:** Lesson 9/75 · Call, Appointment & Agent Reports | Kyntlo Course – Module 2: Dashboard & Reports

**Description:**

```
📚 Kyntlo Course · Lesson 9 of 75 · Module 2 of 15: Dashboard & Reports

Use Call Reporting, the Appointment Report and Agent Reporting to see how many calls you answer, how many patients show up, and how each team member is performing.

Chapters:
0:00 Intro
0:12 Call Reporting
0:25 When calls are missed
0:40 Calls by source
0:57 Recordings & filters
1:11 Appointment Report
1:22 How patients book
1:36 Show rate by calendar
1:50 Agent Reporting
2:02 Reading it fairly
2:19 Speed of reply
2:36 Pro tip

◀ Previous: Lesson 8 · Google & Facebook Ads Reporting
▶ Next: Lesson 10 · The Contact List
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Calltracking #Appointmentreport #Teamperformance
```

## Playlist: Kyntlo Academy · Module 3 — Contacts / CRM

### 3.1 · The contact list (2:44)

**Title:** Lesson 10/75 · The Contact List | Kyntlo Course – Module 3: Contacts

**Description:**

```
📚 Kyntlo Course · Lesson 10 of 75 · Module 3 of 15: Contacts

Find anyone in seconds: search, advanced filters, sorting and columns in your Kyntlo contact list, and how to save the views you use every day as smart lists.

Chapters:
0:00 Intro
0:13 Your contacts
0:27 Reading the list
0:38 Search
0:48 Advanced filters
1:17 Sorting
1:30 Columns
1:49 Smart lists
2:18 Pro tip

◀ Previous: Lesson 9 · Call, Appointment & Agent Reports
▶ Next: Lesson 11 · Adding & Importing Contacts
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMtutorial #Contacts #Smartlists
```

### 3.2 · Adding & importing contacts (2:56)

**Title:** Lesson 11/75 · Adding & Importing Contacts | Kyntlo Course – Module 3: Contacts

**Description:**

```
📚 Kyntlo Course · Lesson 11 of 75 · Module 3 of 15: Contacts

Add contacts by hand, import a CSV spreadsheet, map columns to Kyntlo fields and custom fields, and keep duplicates out of your CRM.

Chapters:
0:00 Intro
0:12 Where contacts come from
0:27 Add a contact
1:07 Avoiding duplicates
1:33 Import a spreadsheet
1:44 Map your fields
1:57 Import options
2:19 Start the import
2:29 Pro tip

◀ Previous: Lesson 10 · The Contact List
▶ Next: Lesson 12 · Inside a Contact Record
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMtutorial #Importcontacts #CSVimport
```

### 3.3 · Inside a contact record (2:50)

**Title:** Lesson 12/75 · Inside a Contact Record | Kyntlo Course – Module 3: Contacts

**Description:**

```
📚 Kyntlo Course · Lesson 12 of 75 · Module 3 of 15: Contacts

Tour the Kyntlo contact record: contact details, the activity timeline, replying, notes, tasks, appointments, opportunities and Do Not Disturb.

Chapters:
0:00 Intro
0:11 Opening a contact
0:32 Contact details
0:44 The timeline
0:59 Replying
1:14 Notes
1:35 Appointments
1:45 Opportunities
1:56 Do Not Disturb
2:24 Pro tip

◀ Previous: Lesson 11 · Adding & Importing Contacts
▶ Next: Lesson 13 · Tags, Custom Fields & Values
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMtutorial #Contactrecord #DoNotDisturb
```

### 3.4 · Tags, custom fields & custom values (3:01)

**Title:** Lesson 13/75 · Tags, Custom Fields & Values | Kyntlo Course – Module 3: Contacts

**Description:**

```
📚 Kyntlo Course · Lesson 13 of 75 · Module 3 of 15: Contacts

Organise your Kyntlo data so automations can use it: when to use a tag, a custom field or a custom value, and how to personalise messages with them.

Chapters:
0:00 Intro
0:14 Three tools, three jobs
0:32 Tags
0:49 Why tags matter
1:03 Custom fields
1:32 Creating fields
1:52 Custom values
2:05 Personalise a message
2:34 Pro tip

◀ Previous: Lesson 12 · Inside a Contact Record
▶ Next: Lesson 14 · Smart Lists & Bulk Actions
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMtutorial #Tags #Customfields #Customvalues
```

### 3.5 · Smart lists & bulk actions (2:52)

**Title:** Lesson 14/75 · Smart Lists & Bulk Actions | Kyntlo Course – Module 3: Contacts

**Description:**

```
📚 Kyntlo Course · Lesson 14 of 75 · Module 3 of 15: Contacts

Segment your contacts with smart lists and filters, then tag, text, email, enrol and export whole groups at once with bulk actions.

Chapters:
0:00 Intro
0:12 Why bulk actions
0:29 Smart lists
0:39 Build a segment
0:49 Select contacts
0:59 Bulk tag
1:14 Bulk SMS
1:51 Workflows & export
2:08 Bulk Actions log
2:24 Pro tip

◀ Previous: Lesson 13 · Tags, Custom Fields & Values
▶ Next: Lesson 15 · Companies & Merging Duplicates
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMtutorial #Smartlists #BulkSMS #Exportcontacts
```

### 3.6 · Companies & restoring / merging duplicates (2:57)

**Title:** Lesson 15/75 · Companies & Merging Duplicates | Kyntlo Course – Module 3: Contacts

**Description:**

```
📚 Kyntlo Course · Lesson 15 of 75 · Module 3 of 15: Contacts

Keep your Kyntlo database clean: group contacts under companies, merge duplicate contacts without losing history, and restore contacts deleted by mistake.

Chapters:
0:00 Intro
0:17 Companies
0:29 Add a company
0:39 Inside a company
1:04 Spotting duplicates
1:21 Merging contacts
2:08 Restoring contacts
2:29 Pro tip

◀ Previous: Lesson 14 · Smart Lists & Bulk Actions
▶ Next: Lesson 16 · Unified Inbox Tour
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #CRMtutorial #Mergeduplicates #Companies
```

## Playlist: Kyntlo Academy · Module 4 — Conversations: the Unified Inbox

### 4.1 · Inbox tour: your unified Conversations inbox (3:05)

**Title:** Lesson 16/75 · Unified Inbox Tour | Kyntlo Course – Module 4: Conversations

**Description:**

```
📚 Kyntlo Course · Lesson 16 of 75 · Module 4 of 15: Conversations

Tour the Kyntlo Conversations inbox: the three panes, channel badges, the Unread, Recents, Starred and All views, search and filters, assigning conversations to your team, starring and marking as unread.

Chapters:
0:00 Intro
0:14 Where it lives
0:30 Three panes
0:44 Reading the list
1:00 Opening a conversation
1:18 Unread, Recents, Starred, All
1:31 Search
1:43 Filters
1:57 Assigning conversations
2:13 Star & mark unread
2:25 Contact panel
2:42 Pro tip

◀ Previous: Lesson 15 · Companies & Merging Duplicates
▶ Next: Lesson 17 · Reply on Every Channel
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Unifiedinbox #Conversations
```

### 4.2 · Replying across channels: SMS, email, WhatsApp, Facebook, Instagram & chat (2:59)

**Title:** Lesson 17/75 · Reply on Every Channel | Kyntlo Course – Module 4: Conversations

**Description:**

```
📚 Kyntlo Course · Lesson 17 of 75 · Module 4 of 15: Conversations

Reply to customers on any channel from one thread in Kyntlo: SMS, email, WhatsApp, Facebook Messenger, Instagram DMs and website live chat, plus internal comments for your team.

Chapters:
0:00 Intro
0:13 One thread per person
0:26 Channel labels & AI replies
0:39 The composer
0:54 Reply by text
1:10 WhatsApp
1:32 Email
1:47 Facebook & Instagram
2:02 Live chat
2:20 Internal comments
2:32 Pro tip

◀ Previous: Lesson 16 · Unified Inbox Tour
▶ Next: Lesson 18 · Snippets, Templates & Scheduling
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Unifiedinbox #SMS #WhatsApp #InstagramDMs
```

### 4.3 · Snippets, templates & scheduled messages (2:54)

**Title:** Lesson 18/75 · Snippets, Templates & Scheduling | Kyntlo Course – Module 4: Conversations

**Description:**

```
📚 Kyntlo Course · Lesson 18 of 75 · Module 4 of 15: Conversations

Reply faster in Kyntlo Conversations: create snippets with custom values, insert them in one click, use email templates, and schedule messages to send later.

Chapters:
0:00 Intro
0:12 Why snippets
0:27 Custom values
0:39 Add a snippet
0:55 Save it
1:10 Use a snippet
1:26 Email templates
1:39 Schedule a message
1:52 Scheduled
2:03 Write now, send later
2:17 More composer tools
2:29 Pro tip

◀ Previous: Lesson 17 · Reply on Every Channel
▶ Next: Lesson 19 · Website Chat Widget Setup
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Snippets #Cannedresponses #Schedulemessage
```

### 4.4 · Setting up the website chat widget (3:08)

**Title:** Lesson 19/75 · Website Chat Widget Setup | Kyntlo Course – Module 4: Conversations

**Description:**

```
📚 Kyntlo Course · Lesson 19 of 75 · Module 4 of 15: Conversations

Turn website visitors into conversations: choose live chat or SMS, style the chat bubble, write your greeting, pick the contact form fields, switch on Conversation AI, test the widget and install it on any website.

Chapters:
0:00 Intro
0:12 Where it lives
0:27 Live chat or SMS
0:45 Style & colours
1:03 Greeting
1:19 Contact form
1:34 Conversation AI
1:46 Acknowledgement
1:57 Test it
2:09 Get the code
2:34 On Kyntlo pages

◀ Previous: Lesson 18 · Snippets, Templates & Scheduling
▶ Next: Lesson 20 · Calls & Missed-Call Text-Back
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Chatwidget #Livechat #Leadcapture
```

### 4.5 · Calls, voicemail & missed-call text-back (2:51)

**Title:** Lesson 20/75 · Calls & Missed-Call Text-Back | Kyntlo Course – Module 4: Conversations

**Description:**

```
📚 Kyntlo Course · Lesson 20 of 75 · Module 4 of 15: Conversations

Make and log calls from the Kyntlo inbox, listen to call recordings and voicemail transcripts, and use missed-call text-back to turn missed calls into booked appointments.

Chapters:
0:00 Intro
0:12 Calls in the thread
0:25 Call recordings
0:38 Making a call
0:53 After the call
1:08 Voicemail
1:20 Calling back
1:30 Missed-call text-back
1:43 From missed call to booking
1:56 New callers become contacts
2:10 How it is set up
2:23 Pro tip

◀ Previous: Lesson 19 · Website Chat Widget Setup
▶ Next: Lesson 21 · Calendar Types Explained
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Missedcalltextback #Callrecording #Voicemail
```

## Playlist: Kyntlo Academy · Module 5 — Calendars & Booking

### 5.1 · Calendar types explained (2:53)

**Title:** Lesson 21/75 · Calendar Types Explained | Kyntlo Course – Module 5: Calendars & Booking

**Description:**

```
📚 Kyntlo Course · Lesson 21 of 75 · Module 5 of 15: Calendars & Booking

Personal booking, round robin, class booking, collective booking, service menu and event calendars: what each Kyntlo calendar type does, and which one to use for every kind of appointment.

Chapters:
0:00 Intro
0:12 Where calendars live
0:26 Choosing a type
0:40 Personal Booking
0:53 Round Robin
1:07 Class Booking
1:19 Collective Booking
1:33 Service Menu
1:47 Event Calendar
2:00 Types in your list
2:12 Which one should I pick?
2:29 Pro tip

◀ Previous: Lesson 20 · Calls & Missed-Call Text-Back
▶ Next: Lesson 22 · Your First Booking Calendar
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Onlinebooking #Calendars #Roundrobin
```

### 5.2 · Creating your first booking calendar (2:59)

**Title:** Lesson 22/75 · Your First Booking Calendar | Kyntlo Course – Module 5: Calendars & Booking

**Description:**

```
📚 Kyntlo Course · Lesson 22 of 75 · Module 5 of 15: Calendars & Booking

Build a booking calendar in Kyntlo step by step: name and booking link, team member and location, meeting duration, weekly hours, date-specific hours, buffers, minimum notice and booking limits.

Chapters:
0:00 Intro
0:11 Create the calendar
0:25 Name & booking link
0:40 Team member & location
0:53 Duration
1:08 Weekly hours
1:25 Date-specific hours
1:37 Buffers & notice
1:51 Booking limits
2:06 Save & share
2:23 Preview
2:36 Pro tip

◀ Previous: Lesson 21 · Calendar Types Explained
▶ Next: Lesson 23 · Booking Forms & Payments
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Onlinebooking #Bookingcalendar #Availability
```

### 5.3 · Booking forms, confirmations & payments (3:02)

**Title:** Lesson 23/75 · Booking Forms & Payments | Kyntlo Course – Module 5: Calendars & Booking

**Description:**

```
📚 Kyntlo Course · Lesson 23 of 75 · Module 5 of 15: Calendars & Booking

Collect the right information when people book a Kyntlo calendar, take a deposit through Stripe, choose what happens after booking, and send booking confirmations automatically.

Chapters:
0:00 Intro
0:11 Open the calendar
0:25 The default form
0:38 A custom form
0:53 Consent
1:03 Accept payments
1:17 Deposit amount
1:30 Receipt description
1:46 After booking
1:58 Confirmations
2:11 Auto-confirm
2:28 Test it
2:39 Pro tip

◀ Previous: Lesson 22 · Your First Booking Calendar
▶ Next: Lesson 24 · Google & Outlook Calendar Sync
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Onlinebooking #Bookingdeposits #Stripe
```

### 5.4 · Connecting Google & Outlook calendars (2:59)

**Title:** Lesson 24/75 · Google & Outlook Calendar Sync | Kyntlo Course – Module 5: Calendars & Booking

**Description:**

```
📚 Kyntlo Course · Lesson 24 of 75 · Module 5 of 15: Calendars & Booking

Connect Google Calendar or Outlook to Kyntlo, choose a linked calendar for two-way sync, add conflict calendars so private plans block your availability, and add Zoom or Google Meet links.

Chapters:
0:00 Intro
0:11 Why connect
0:24 One connection per person
0:39 Connect Outlook
0:50 Linked calendar
1:04 Conflict calendars
1:18 What to leave out
1:30 Save
1:40 What two-way sync means
1:57 Managing a connection
2:10 Check your time zone
2:23 Video meetings
2:36 Pro tip

◀ Previous: Lesson 23 · Booking Forms & Payments
▶ Next: Lesson 25 · Managing Appointments & No-Shows
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #GoogleCalendarsync #Outlookcalendar #Doublebooking
```

### 5.5 · Managing appointments: book, reschedule, cancel & no-shows (3:00)

**Title:** Lesson 25/75 · Managing Appointments & No-Shows | Kyntlo Course – Module 5: Calendars & Booking

**Description:**

```
📚 Kyntlo Course · Lesson 25 of 75 · Module 5 of 15: Calendars & Booking

Run your diary in Kyntlo: read the calendar view, filter by calendar and team member, book appointments by hand, reschedule, update statuses, mark no-shows, cancel, and use the appointment list.

Chapters:
0:00 Intro
0:11 The calendar view
0:26 Views & filters
0:44 Book an appointment
1:00 Pick the details
1:14 Appointment details
1:28 Reschedule
1:42 Update the status
1:58 No-shows
2:10 Cancel
2:26 Appointment List
2:38 Pro tip

◀ Previous: Lesson 24 · Google & Outlook Calendar Sync
▶ Next: Lesson 26 · Automatic Appointment Reminders
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Appointments #No-shows #Calendarview
```

### 5.6 · Automatic appointment reminders (3:02)

**Title:** Lesson 26/75 · Automatic Appointment Reminders | Kyntlo Course – Module 5: Calendars & Booking

**Description:**

```
📚 Kyntlo Course · Lesson 26 of 75 · Module 5 of 15: Calendars & Booking

Cut no-shows with automatic email and SMS appointment reminders in Kyntlo: notifications vs reminders, adding a reminder, timing and message templates, consent and DND, and when to use a workflow instead.

Chapters:
0:00 Intro
0:11 Why reminders work
0:27 Notifications tab
0:44 Reminders
1:00 Add a reminder
1:14 Timing & message
1:31 Save the reminder
1:46 Consent & DND
2:05 Save
2:19 Going further with workflows
2:36 Pro tip

◀ Previous: Lesson 25 · Managing Appointments & No-Shows
▶ Next: Lesson 27 · Pipelines Explained
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Appointmentreminders #No-shows #SMSreminders
```

## Playlist: Kyntlo Academy · Module 6 — Opportunities & Pipelines

### 6.1 · Pipelines explained (3:05)

**Title:** Lesson 27/75 · Pipelines Explained | Kyntlo Course – Module 6: Pipelines

**Description:**

```
📚 Kyntlo Course · Lesson 27 of 75 · Module 6 of 15: Pipelines

What opportunities and pipelines are, how stages, values and statuses (open, won, lost, abandoned) work, why stage and status are separate, and how many pipelines each Kyntlo plan includes.

Chapters:
0:00 Intro
0:14 Contacts vs opportunities
0:30 What a pipeline is
0:43 Stages
1:01 Counts & values
1:12 Opportunity cards
1:28 Why values matter
1:47 Statuses
2:01 Stage vs status
2:15 Lost reasons
2:26 More than one pipeline
2:41 Pro tip

◀ Previous: Lesson 26 · Automatic Appointment Reminders
▶ Next: Lesson 28 · Building a Pipeline
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Salespipeline #Opportunities #CRM
```

### 6.2 · Building a pipeline (2:56)

**Title:** Lesson 28/75 · Building a Pipeline | Kyntlo Course – Module 6: Pipelines

**Description:**

```
📚 Kyntlo Course · Lesson 28 of 75 · Module 6 of 15: Pipelines

Plan your sales stages, create a new pipeline, name and add stages, drag them into the right order, choose which stages appear in your charts, and edit an existing pipeline safely.

Chapters:
0:00 Intro
0:12 Plan your stages first
0:33 The Pipelines tab
0:46 Create a pipeline
1:04 Add stages
1:24 Funnel & pie charts
1:37 Save
1:48 See it on the board
2:05 Editing a pipeline
2:20 Pipelines on your plan
2:31 Pro tip

◀ Previous: Lesson 27 · Pipelines Explained
▶ Next: Lesson 29 · Working the Pipeline Board
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Salespipeline #Pipelinestages #CRMsetup
```

### 6.3 · Working the board (2:54)

**Title:** Lesson 29/75 · Working the Pipeline Board | Kyntlo Course – Module 6: Pipelines

**Description:**

```
📚 Kyntlo Course · Lesson 29 of 75 · Module 6 of 15: Pipelines

Work your pipeline every day: drag deals between stages, move them from the card menu, update status and lost reasons, add opportunities, search and filter, switch to list view and use bulk actions.

Chapters:
0:00 Intro
0:12 Drag a deal
0:26 Move from the card menu
0:38 Mark a deal as won
0:50 Lost, with a reason
1:02 Add an opportunity
1:16 Create it
1:37 Filter by owner
1:47 List view
2:01 Bulk actions
2:14 Back to the board
2:28 Pro tip

◀ Previous: Lesson 28 · Building a Pipeline
▶ Next: Lesson 30 · Pipeline Reporting
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Salespipeline #Opportunities #Bulkactions
```

### 6.4 · Pipeline reporting (2:59)

**Title:** Lesson 30/75 · Pipeline Reporting | Kyntlo Course – Module 6: Pipelines

**Description:**

```
📚 Kyntlo Course · Lesson 30 of 75 · Module 6 of 15: Pipelines

Turn your pipeline into numbers: opportunity status and value, conversion rate, the stage-by-stage funnel, stage distribution, column totals, lost reasons and won value per team member.

Chapters:
0:00 Intro
0:13 Where pipeline reports live
0:26 Status & value
0:39 Conversion rate
0:56 Find the leak in the funnel
1:12 Fixing the leak
1:27 Stage distribution
1:41 Totals on the board
1:56 Why deals are lost
2:10 Won value per person
2:30 Pro tip

◀ Previous: Lesson 29 · Working the Pipeline Board
▶ Next: Lesson 31 · Funnels vs. Websites
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Pipelinereporting #Conversionrate #Salesfunnel
```

## Playlist: Kyntlo Academy · Module 7 — Sites: Funnels, Websites & Forms

### 7.1 · Funnels vs. websites (2:48)

**Title:** Lesson 31/75 · Funnels vs. Websites | Kyntlo Course – Module 7: Funnels & Websites

**Description:**

```
📚 Kyntlo Course · Lesson 31 of 75 · Module 7 of 15: Funnels & Websites

Understand the difference between a funnel and a website in Kyntlo, when to use each one, and how they work together to turn visitors into booked appointments.

Chapters:
0:00 Intro
0:13 The Sites area
0:28 What a funnel is
0:46 Funnel steps
1:00 Why funnels convert
1:13 What a website is
1:30 Website pages
1:43 Which one when?
1:56 Working together
2:14 One builder for both
2:26 Pro tip

◀ Previous: Lesson 30 · Pipeline Reporting
▶ Next: Lesson 32 · Build a Funnel from a Template
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Funnels #Websitebuilder #Landingpages
```

### 7.2 · Build a funnel from a template (2:47)

**Title:** Lesson 32/75 · Build a Funnel from a Template | Kyntlo Course – Module 7: Funnels & Websites

**Description:**

```
📚 Kyntlo Course · Lesson 32 of 75 · Module 7 of 15: Funnels & Websites

Create a complete funnel in minutes: pick a template from the library, preview it, make it yours with your logo, headline, button and images, then save, publish and set a clean URL.

Chapters:
0:00 Intro
0:23 Templates library
0:36 Preview first
0:47 Name your funnel
0:58 Your new steps
1:11 Your logo & phone
1:21 Headline
1:42 Images
1:54 Save & publish
2:13 Next steps
2:23 Pro tip

◀ Previous: Lesson 31 · Funnels vs. Websites
▶ Next: Lesson 33 · The Page Builder in Depth
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Funneltemplates #Landingpage #Funnelbuilder
```

### 7.3 · The page builder in depth (3:20)

**Title:** Lesson 33/75 · The Page Builder in Depth | Kyntlo Course – Module 7: Funnels & Websites

**Description:**

```
📚 Kyntlo Course · Lesson 33 of 75 · Module 7 of 15: Funnels & Websites

Master the Kyntlo drag-and-drop page builder: how sections, rows, columns and elements fit together, editing text and styles, adding elements, mobile view, preview, save and publish.

Chapters:
0:00 Intro
0:12 Builder tour
0:28 How pages are built
0:43 Rows & columns
0:57 Elements
1:11 Editing text
1:23 Styling
1:35 Adding elements
1:47 Element settings
2:01 Rows & sections
2:17 Mobile view
2:30 Hide on mobile
2:44 Preview & publish
2:56 Pro tip

◀ Previous: Lesson 32 · Build a Funnel from a Template
▶ Next: Lesson 34 · Forms & Surveys
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Pagebuilder #Landingpage #Draganddrop
```

### 7.4 · Forms & surveys (3:03)

**Title:** Lesson 34/75 · Forms & Surveys | Kyntlo Course – Module 7: Funnels & Websites

**Description:**

```
📚 Kyntlo Course · Lesson 34 of 75 · Module 7 of 15: Funnels & Websites

Build lead forms that fill your CRM: standard and custom fields, required fields, conditional logic, what happens on submit, notifications, styling and embedding. Plus multi-step surveys with progress bars and jump logic.

Chapters:
0:00 Intro
0:13 Your forms
0:28 The form builder
0:53 Add a field
1:04 Conditional logic
1:19 On submit
1:33 Notifications & follow-up
1:48 Styles
2:10 On Kyntlo pages
2:29 Slides & logic
2:42 Pro tip

◀ Previous: Lesson 33 · The Page Builder in Depth
▶ Next: Lesson 35 · Connecting Your Domain
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Formbuilder #Surveys #Leadcapture
```

### 7.5 · Connecting your domain (3:04)

**Title:** Lesson 35/75 · Connecting Your Domain | Kyntlo Course – Module 7: Funnels & Websites

**Description:**

```
📚 Kyntlo Course · Lesson 35 of 75 · Module 7 of 15: Funnels & Websites

Put your funnels and websites on your own web address: add a domain or subdomain, create the DNS records at your domain provider, verify them, link the domain to a funnel with a default page, and get free SSL.

Chapters:
0:00 Intro
0:12 Your domains
0:26 Domain or subdomain?
0:44 Add a domain
0:55 Enter the address
1:19 At your provider
1:35 Verify
1:47 Link the domain
1:59 Default page
2:10 Free SSL
2:24 Your new URL
2:42 Pro tip

◀ Previous: Lesson 34 · Forms & Surveys
▶ Next: Lesson 36 · Funnel Stats, A/B Tests & SEO
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Customdomain #DNS #SSL
```

### 7.6 · Funnel stats, A/B tests & SEO (2:52)

**Title:** Lesson 36/75 · Funnel Stats, A/B Tests & SEO | Kyntlo Course – Module 7: Funnels & Websites

**Description:**

```
📚 Kyntlo Course · Lesson 36 of 75 · Module 7 of 15: Funnels & Websites

Measure and improve your funnels: read page views, opt-ins and opt-in rates, find where visitors drop off, run an A/B split test and declare a winner, then set SEO meta data and tracking code.

Chapters:
0:00 Intro
0:12 Funnel stats
0:28 All vs. uniques
0:41 Find the leak
0:56 Create an A/B test
1:08 Change one thing
1:18 Traffic split
1:30 Reading results
1:44 Declare a winner
2:06 Writing a good title
2:19 Tracking code
2:30 Pro tip

◀ Previous: Lesson 35 · Connecting Your Domain
▶ Next: Lesson 37 · Blogs & QR Codes
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Funnelanalytics #A/Btesting #SEO
```

### 7.7 · Blogs & QR codes (2:55)

**Title:** Lesson 37/75 · Blogs & QR Codes | Kyntlo Course – Module 7: Funnels & Websites

**Description:**

```
📚 Kyntlo Course · Lesson 37 of 75 · Module 7 of 15: Funnels & Websites

Publish blog posts that bring in search traffic, draft them faster with Content AI, set slugs and meta descriptions, schedule posts, then create trackable QR codes that bring offline visitors to your pages.

Chapters:
0:00 Intro
0:12 Your blog
0:25 Categories & authors
0:35 New post
0:46 Content AI
0:59 Review & edit
1:10 Post settings
1:21 Schedule it
1:43 Create a QR code
1:54 Track it with UTMs
2:06 Design & download
2:18 Measuring results
2:28 Pro tip

◀ Previous: Lesson 36 · Funnel Stats, A/B Tests & SEO
▶ Next: Lesson 38 · Email Builder & Templates
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Blog #QRcodes #ContentAI
```

## Playlist: Kyntlo Academy · Module 8 — Marketing: Email, SMS & Social

### 8.1 · Email builder & templates (2:49)

**Title:** Lesson 38/75 · Email Builder & Templates | Kyntlo Course – Module 8: Marketing

**Description:**

```
📚 Kyntlo Course · Lesson 38 of 75 · Module 8 of 15: Marketing

Design a branded marketing email in Kyntlo: start from a template, edit text and buttons, add personalised merge fields, drag in new elements, check the mobile view and send yourself a test.

Chapters:
0:00 Intro
0:12 Where emails live
0:25 Choose a template
0:41 The builder
0:55 Name your campaign
1:18 Edit the button
1:32 Drag in new elements
1:47 Check the mobile view
2:00 Send a test email
2:13 Save your work
2:27 Pro tip

◀ Previous: Lesson 37 · Blogs & QR Codes
▶ Next: Lesson 39 · Sending an Email Campaign
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Emailmarketing #Emailbuilder #Emailtemplates
```

### 8.2 · Sending an email campaign (3:07)

**Title:** Lesson 39/75 · Sending an Email Campaign | Kyntlo Course – Module 8: Marketing

**Description:**

```
📚 Kyntlo Course · Lesson 39 of 75 · Module 8 of 15: Marketing

Send an email campaign in Kyntlo: choose your audience by tag or smart list, set the sender, write a subject line and preview text, test it, schedule it, and read the results.

Chapters:
0:00 Intro
0:11 Open your draft
0:24 Choose your audience
0:39 Who gets skipped
0:52 Sender details
1:09 Subject line & preview text
1:25 Test before you send
1:37 Schedule it
1:50 Sending in batches
2:03 Confirm & schedule
2:15 Reading the results
2:30 Links & recipients
2:44 Pro tip

◀ Previous: Lesson 38 · Email Builder & Templates
▶ Next: Lesson 40 · Email Deliverability Basics
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Emailmarketing #Emailcampaigns #Newsletter
```

### 8.3 · Email deliverability basics (3:22)

**Title:** Lesson 40/75 · Email Deliverability Basics | Kyntlo Course – Module 8: Marketing

**Description:**

```
📚 Kyntlo Course · Lesson 40 of 75 · Module 8 of 15: Marketing

Get your Kyntlo emails into the inbox, not the spam folder: read your bounce and complaint numbers, set up a dedicated sending domain, turn on email verification, warm up with batches and keep your list healthy.

Chapters:
0:00 Intro
0:11 What deliverability means
0:25 Healthy numbers
0:40 Why use your own domain
0:56 Add a sending domain
1:09 DNS records explained
1:25 Verify the domain
1:39 Email verification
1:55 Warm up a new domain
2:10 Send in batches
2:23 Write like a human
2:37 Keep your list clean
2:54 Pro tip

◀ Previous: Lesson 39 · Sending an Email Campaign
▶ Next: Lesson 41 · SMS & WhatsApp Broadcasts
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Emaildeliverability #SPFDKIMDMARC #Emailmarketing
```

### 8.4 · SMS & WhatsApp broadcasts (3:19)

**Title:** Lesson 41/75 · SMS & WhatsApp Broadcasts | Kyntlo Course – Module 8: Marketing

**Description:**

```
📚 Kyntlo Course · Lesson 41 of 75 · Module 8 of 15: Marketing

Send text message and WhatsApp broadcasts the right way: consent and opt-outs, reusable SMS templates with a segment counter, Meta-approved WhatsApp templates, and bulk sending from Contacts in drip mode.

Chapters:
0:00 Intro
0:17 Consent comes first
0:36 SMS templates
0:51 Create a text template
1:06 Characters & segments
1:23 Add opt-out text
1:38 WhatsApp templates
1:52 Template approval
2:09 Send a broadcast
2:23 Drip mode
2:40 Track progress
2:54 Pro tip

◀ Previous: Lesson 40 · Email Deliverability Basics
▶ Next: Lesson 42 · Social Planner
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #SMSmarketing #WhatsAppmarketing #Textmessagecompliance
```

### 8.5 · Social Planner (3:01)

**Title:** Lesson 42/75 · Social Planner | Kyntlo Course – Module 8: Marketing

**Description:**

```
📚 Kyntlo Course · Lesson 42 of 75 · Module 8 of 15: Marketing

Plan and schedule social media posts in Kyntlo: connect Facebook, Instagram, Google Business Profile, LinkedIn, TikTok and X, use the calendar and list views, write posts with Content AI, preview them per network and set up recurring posts.

Chapters:
0:00 Intro
0:11 Your social calendar
0:25 Connect your accounts
0:39 Week & list views
0:54 Create a post
1:06 Write with Content AI
1:23 Add an image
1:35 Preview each network
1:49 Google Business posts
2:04 Schedule it
2:20 Recurring posts
2:34 Pro tip

◀ Previous: Lesson 41 · SMS & WhatsApp Broadcasts
▶ Next: Lesson 43 · Trigger Links & Link Tracking
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Socialmediascheduling #SocialPlanner #ContentAI
```

### 8.6 · Trigger links & link tracking (2:44)

**Title:** Lesson 43/75 · Trigger Links & Link Tracking | Kyntlo Course – Module 8: Marketing

**Description:**

```
📚 Kyntlo Course · Lesson 43 of 75 · Module 8 of 15: Marketing

Use trigger links in Kyntlo to see exactly which contacts clicked a link in your emails and texts, and start automations when they do: create a link, copy its key, use it in a campaign and read the click analytics.

Chapters:
0:00 Intro
0:12 What trigger links are
0:26 Create a link
0:40 Copy the link key
0:51 Use it in an email
1:05 What happens on a click
1:19 Act on clicks
1:36 Analyze your links
1:48 Who clicked
2:00 Trigger links vs email stats
2:17 Pro tip

◀ Previous: Lesson 42 · Social Planner
▶ Next: Lesson 44 · How Workflows Work
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Triggerlinks #Linktracking #Marketingautomation
```

## Playlist: Kyntlo Academy · Module 9 — Automation: Workflows

### 9.1 · How workflows think: triggers, actions & conditions (3:19)

**Title:** Lesson 44/75 · How Workflows Work | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 44 of 75 · Module 9 of 15: Automation

Understand the logic behind every Kyntlo workflow: triggers decide who enters, actions run top to bottom, waits pause, and If/Else conditions send each contact down the right path.

Chapters:
0:00 Intro
0:15 Where workflows live
0:30 Open a workflow
0:41 Triggers: the "when"
0:57 Trigger filters
1:16 Actions: the "what"
1:37 Waits
1:52 Conditions: If/Else
2:10 One contact at a time
2:25 Draft & publish
2:38 Your plan
2:51 Pro tip

◀ Previous: Lesson 43 · Trigger Links & Link Tracking
▶ Next: Lesson 45 · Your First Workflow
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #Marketingautomation
```

### 9.2 · Your first workflow: new-lead follow-up (3:10)

**Title:** Lesson 45/75 · Your First Workflow | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 45 of 75 · Module 9 of 15: Automation

Build your first Kyntlo workflow from scratch: a form trigger with a filter, an instant SMS with custom values, a team notification, a wait and a follow-up email. Then test it and publish it.

Chapters:
0:00 Intro
0:14 Why speed matters
0:29 Create the workflow
0:41 Name it
0:51 Add the trigger
1:05 Send an instant SMS
1:16 Personalise with custom values
1:31 Notify your team
1:43 Wait, then follow up
2:00 Workflow settings
2:16 Test it
2:32 Publish
2:43 Pro tip

◀ Previous: Lesson 44 · How Workflows Work
▶ Next: Lesson 46 · If/Else, Waits & Goals
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #Leadfollow-up #Speedtolead
```

### 9.3 · If/Else, waits & goals (2:59)

**Title:** Lesson 46/75 · If/Else, Waits & Goals | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 46 of 75 · Module 9 of 15: Automation

Make your workflows react to what people do: use Wait steps, split contacts with If/Else branches, and use Goal Events to stop chasing people who already did what you wanted.

Chapters:
0:00 Intro
0:16 The starting point
0:29 Wait options
0:44 A simple time delay
0:56 Add an If/Else
1:11 Two lanes
1:23 The Replied branch
1:35 The None branch
1:47 Goal events
2:05 If the goal is not met
2:16 The whole picture
2:31 Pro tip

◀ Previous: Lesson 45 · Your First Workflow
▶ Next: Lesson 47 · Appointment Workflows
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #If/Else #Marketingautomation
```

### 9.4 · Appointment workflows: confirmations, reminders & no-shows (3:02)

**Title:** Lesson 47/75 · Appointment Workflows | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 47 of 75 · Module 9 of 15: Automation

Cut no-shows with appointment workflows: confirm every booking, send reminders timed to the appointment, recover no-shows automatically and ask happy patients for a review.

Chapters:
0:00 Intro
0:14 The Appointments folder
0:25 Trigger: booked appointment
0:41 Instant confirmation
0:55 Reminders timed to the appointment
1:10 A second reminder
1:24 Allow re-entry
1:37 No-show recovery
1:51 A friendly second chance
2:05 Review request after the visit
2:18 Keep reminders running
2:34 Pro tip

◀ Previous: Lesson 46 · If/Else, Waits & Goals
▶ Next: Lesson 48 · Pipeline Automation
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #Appointmentreminders #No-shows
```

### 9.5 · Pipeline automation: move deals and create tasks (2:57)

**Title:** Lesson 48/75 · Pipeline Automation | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 48 of 75 · Module 9 of 15: Automation

Keep your pipeline up to date without dragging cards: use workflows to create and move opportunities, tag contacts, create tasks for your team, and react when deals are won.

Chapters:
0:00 Intro
0:16 The plan
0:28 Create the workflow
0:48 Create or update the opportunity
1:05 Two important switches
1:23 Tag the contact
1:35 Create a task
1:47 Publish
2:01 Opportunity triggers
2:16 When a deal is won
2:31 Pro tip

◀ Previous: Lesson 47 · Appointment Workflows
▶ Next: Lesson 49 · Workflow Recipes & Templates
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #Pipelines #Opportunities
```

### 9.6 · Workflow recipes & templates (2:48)

**Title:** Lesson 49/75 · Workflow Recipes & Templates | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 49 of 75 · Module 9 of 15: Automation

Start new automations in seconds: browse the workflow recipes, set up Missed Call Text Back from a recipe, customise the message and settings, and clone your own proven workflows.

Chapters:
0:00 Intro
0:13 Find the recipes
0:46 Preview a recipe
0:59 Use the recipe
1:13 Check the trigger
1:24 Make the message yours
1:41 Name it & publish
2:04 Organise in folders
2:22 Pro tip

◀ Previous: Lesson 48 · Pipeline Automation
▶ Next: Lesson 50 · Webhooks & Google Sheets
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #Workflowrecipes #Missedcalltextback
```

### 9.7 · Webhooks, Google Sheets & premium actions (2:55)

**Title:** Lesson 50/75 · Webhooks & Google Sheets | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 50 of 75 · Module 9 of 15: Automation

Connect Kyntlo to your other tools without Zapier: start workflows from an inbound webhook, add rows to Google Sheets, send data out with webhooks, and understand how premium actions are billed.

Chapters:
0:00 Intro
0:14 What premium means
0:30 The example
0:44 Inbound webhook trigger
0:54 Fetch a sample
1:07 Create the contact
1:22 Google Sheets action
1:32 Map the columns
1:48 Sending data out
2:06 Configure the webhook
2:18 Other premium actions
2:29 Pro tip

◀ Previous: Lesson 49 · Workflow Recipes & Templates
▶ Next: Lesson 51 · Troubleshooting Workflows
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #Webhooks #GoogleSheets #Integrations
```

### 9.8 · Troubleshooting workflows with execution logs (3:11)

**Title:** Lesson 51/75 · Troubleshooting Workflows | Kyntlo Course – Module 9: Automation

**Description:**

```
📚 Kyntlo Course · Lesson 51 of 75 · Module 9 of 15: Automation

Find out exactly why a contact didn't get a message or didn't move: check the publish status, the trigger filters, Enrollment History and Execution Logs, and fix the cause.

Chapters:
0:00 Intro
0:13 The four checks
0:28 1. Is it published?
0:41 2. Did they enrol?
0:56 3. Check the trigger
1:14 4. Read the execution logs
1:28 Executed, skipped, failed
1:42 View the details
1:55 Fix it on the contact
2:09 Failed steps
2:24 Waiting is normal
2:38 Pro tip

◀ Previous: Lesson 50 · Webhooks & Google Sheets
▶ Next: Lesson 52 · AI Overview: What's in Your Plan
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Workflows #Troubleshooting #Executionlogs
```

## Playlist: Kyntlo Academy · Module 10 — AI in Kyntlo

### 10.1 · AI overview: what's available on your plan (3:05)

**Title:** Lesson 52/75 · AI Overview: What's in Your Plan | Kyntlo Course – Module 10: AI

**Description:**

```
📚 Kyntlo Course · Lesson 52 of 75 · Module 10 of 15: AI

Meet Kyntlo's AI employees (Conversation AI, Voice AI, Knowledge Base, Content AI, Workflow AI and Reviews AI) and see exactly which ones are included on Starter, Growth and Pro, and what pay-as-you-go AI usage costs.

Chapters:
0:00 Intro
0:13 Where AI lives
0:25 Your plan
0:41 Conversation AI
0:57 Voice AI & Knowledge Base
1:09 Content, Workflow & Reviews AI
1:26 Plans compared
1:40 What Pro adds
1:55 Pay-as-you-go rates
2:12 What it costs in practice
2:29 Your learning path
2:43 Pro tip

◀ Previous: Lesson 51 · Troubleshooting Workflows
▶ Next: Lesson 53 · Conversation AI Chatbot
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #AIforbusiness #AIchatbot #VoiceAI #Pricing
```

### 10.2 · Conversation AI chatbot (3:24)

**Title:** Lesson 53/75 · Conversation AI Chatbot | Kyntlo Course – Module 10: AI

**Description:**

```
📚 Kyntlo Course · Lesson 53 of 75 · Module 10 of 15: AI

Set up your Conversation AI chatbot: choose a bot mode (Off, Suggestive or Auto-pilot), pick channels, write its personality and goal, add actions like booking and human handover, and test it before it talks to customers.

Chapters:
0:00 Intro
0:14 Your bots
0:29 Bot mode
0:44 Switching on Auto-pilot
0:54 Channels & handing over
1:07 Personality & goals
1:23 Actions
1:39 Human handover
1:54 Knowledge base
2:07 Test your bot
2:19 Test a booking
2:30 Save & track results
2:45 Plans & usage
2:58 Pro tip

◀ Previous: Lesson 52 · AI Overview: What's in Your Plan
▶ Next: Lesson 54 · AI Knowledge Base & FAQs
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #AIchatbot #ConversationAI #Leadresponse
```

### 10.3 · AI knowledge base & FAQs (2:58)

**Title:** Lesson 54/75 · AI Knowledge Base & FAQs | Kyntlo Course – Module 10: AI

**Description:**

```
📚 Kyntlo Course · Lesson 54 of 75 · Module 10 of 15: AI

Teach your AI agents about your business: crawl your website, add FAQs with exact answers, upload documents like price lists, check training status, then test what your chatbot has learned.

Chapters:
0:00 Intro
0:12 Your knowledge base
0:26 Sources
0:39 Add a source
0:56 Web crawler
1:11 Train the pages
1:21 Training status
1:33 Add an FAQ
1:46 Why FAQs matter
2:02 Upload a file
2:16 Test what it learned
2:33 Pro tip

◀ Previous: Lesson 53 · Conversation AI Chatbot
▶ Next: Lesson 55 · Voice AI Receptionist
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #AIchatbot #Knowledgebase #FAQs
```

### 10.4 · Voice AI receptionist (2:59)

**Title:** Lesson 55/75 · Voice AI Receptionist | Kyntlo Course – Module 10: AI

**Description:**

```
📚 Kyntlo Course · Lesson 55 of 75 · Module 10 of 15: AI

Set up a Voice AI receptionist that answers your phone: pick a voice, write the greeting and goals, set working hours, route calls to your team, book appointments, send a text after every call, and review call logs with summaries and transcripts.

Chapters:
0:00 Intro
0:12 Voice AI agents
0:29 Choose a voice
0:39 Greeting
0:52 Prompt & goals
1:07 Phone & availability
1:22 Call transfer
1:35 Booking & follow-up text
1:47 After every call
2:08 Call logs
2:22 Summary & transcript
2:34 Pro tip

◀ Previous: Lesson 54 · AI Knowledge Base & FAQs
▶ Next: Lesson 56 · Content AI
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #VoiceAI #AIreceptionist #Phoneanswering
```

### 10.5 · Content AI (3:03)

**Title:** Lesson 56/75 · Content AI | Kyntlo Course – Module 10: AI

**Description:**

```
📚 Kyntlo Course · Lesson 56 of 75 · Module 10 of 15: AI

Use Content AI to write emails, social posts, blog posts and website copy in your brand voice, choose the tone and length, send the result straight to your campaigns, and generate images for your posts.

Chapters:
0:00 Intro
0:12 Where to find it
0:31 Choose what to write
0:44 Describe it
1:07 Your email
1:19 Use it
1:36 A social post
1:49 Send to Social Planner
2:13 Pick your favourite
2:24 History
2:37 Pro tip

◀ Previous: Lesson 55 · Voice AI Receptionist
▶ Next: Lesson 57 · AI Inside Workflows
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #ContentAI #AIwriting #Socialmedia
```

### 10.6 · AI inside workflows (3:03)

**Title:** Lesson 57/75 · AI Inside Workflows | Kyntlo Course – Module 10: AI

**Description:**

```
📚 Kyntlo Course · Lesson 57 of 75 · Module 10 of 15: AI

Add AI steps to your automations with Workflow AI: classify incoming messages, summarise conversations into notes, write AI replies, and route complaints to a person. Includes a worked example of AI inbox triage.

Chapters:
0:00 Intro
0:15 What is Workflow AI?
0:31 Classify & summarise
0:50 AI reply & sentiment
1:03 Finding AI actions
1:20 Example: AI inbox triage
1:33 Test a booking request
1:47 Test a price question
2:01 Complaints go to a person
2:16 Bots can start workflows
2:31 Pro tip

◀ Previous: Lesson 56 · Content AI
▶ Next: Lesson 58 · Connect Google Business Profile
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #WorkflowAI #Automation #AIforbusiness
```

## Playlist: Kyntlo Academy · Module 11 — Reputation

### 11.1 · Connecting Google Business Profile (2:51)

**Title:** Lesson 58/75 · Connect Google Business Profile | Kyntlo Course – Module 11: Reputation

**Description:**

```
📚 Kyntlo Course · Lesson 58 of 75 · Module 11 of 15: Reputation

Connect your Google Business Profile to Kyntlo Reputation, pull your Google reviews in, and set the review link your review requests will use.

Chapters:
0:00 Intro
0:12 Reputation before connecting
0:25 Why connect Google
0:44 Before you start
1:02 Sign in with Google
1:17 Choose your location
1:32 Reviews imported
1:43 Managing the connection
1:53 Your review link
2:15 QR code
2:25 Pro tip

◀ Previous: Lesson 57 · AI Inside Workflows
▶ Next: Lesson 59 · Requesting Reviews Automatically
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Reputationmanagement #GoogleBusinessProfile #Googlereviews
```

### 11.2 · Requesting reviews automatically (2:50)

**Title:** Lesson 59/75 · Requesting Reviews Automatically | Kyntlo Course – Module 11: Reputation

**Description:**

```
📚 Kyntlo Course · Lesson 59 of 75 · Module 11 of 15: Reputation

Send review requests by SMS and email, track who clicked and who reviewed, and set Kyntlo to ask every customer automatically with smart follow-ups.

Chapters:
0:00 Intro
0:14 Why ask
0:26 Send a request
0:40 SMS or email
0:59 Send a request
1:24 Automatic requests
1:48 Timing & follow-ups
2:09 The message
2:23 Pro tip

◀ Previous: Lesson 58 · Connect Google Business Profile
▶ Next: Lesson 60 · Replying with Reviews AI
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Reputationmanagement #Reviewrequests #Googlereviews
```

### 11.3 · Responding with Reviews AI (2:52)

**Title:** Lesson 60/75 · Replying with Reviews AI | Kyntlo Course – Module 11: Reputation

**Description:**

```
📚 Kyntlo Course · Lesson 60 of 75 · Module 11 of 15: Reputation

Reply to Google and Facebook reviews from Kyntlo in seconds: set up Reviews AI with your tone and instructions, generate on-brand replies, and handle negative reviews well.

Chapters:
0:00 Intro
0:14 Why reply
0:29 Find unanswered reviews
0:43 Set up Reviews AI
1:00 Your brand voice
1:15 Reply with AI
1:29 Check and post
1:42 Negative reviews
2:07 Auto-pilot
2:24 Pro tip

◀ Previous: Lesson 59 · Requesting Reviews Automatically
▶ Next: Lesson 61 · Review Widgets
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Reputationmanagement #ReviewsAI #Replytoreviews
```

### 11.4 · Review widgets (2:49)

**Title:** Lesson 61/75 · Review Widgets | Kyntlo Course – Module 11: Reputation

**Description:**

```
📚 Kyntlo Course · Lesson 61 of 75 · Module 11 of 15: Reputation

Build a review widget in Kyntlo: choose a layout, sources, minimum rating and theme, then copy the embed code onto your website or Kyntlo funnel.

Chapters:
0:00 Intro
0:13 Why widgets
0:32 The widget builder
0:43 Name
1:10 Sources & ratings
1:24 Theme & display
1:36 Save
1:49 Add it to your site
2:05 Always up to date
2:17 Pro tip

◀ Previous: Lesson 60 · Replying with Reviews AI
▶ Next: Lesson 62 · Connecting Stripe
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Reputationmanagement #Reviewwidget #Socialproof
```

## Playlist: Kyntlo Academy · Module 12 — Payments

### 12.1 · Connecting Stripe (2:52)

**Title:** Lesson 62/75 · Connecting Stripe | Kyntlo Course – Module 12: Payments

**Description:**

```
📚 Kyntlo Course · Lesson 62 of 75 · Module 12 of 15: Payments

Connect Stripe so you can take card payments on invoices, payment links, order forms, calendar bookings and Text2Pay. Covers what you need before you start, test mode, and adding PayPal.

Chapters:
0:00 Intro
0:13 Where to connect
0:33 Before you start
0:47 Connect Stripe
0:58 Authorise the connection
1:15 Connected
1:29 Where the money goes
1:46 Test mode
2:01 Adding PayPal
2:15 Where payments show up
2:28 Pro tip

◀ Previous: Lesson 61 · Review Widgets
▶ Next: Lesson 63 · Products, Prices & Invoices
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Stripe #Payments #Onlinepayments
```

### 12.2 · Products, prices & invoices (2:53)

**Title:** Lesson 63/75 · Products, Prices & Invoices | Kyntlo Course – Module 12: Payments

**Description:**

```
📚 Kyntlo Course · Lesson 63 of 75 · Module 12 of 15: Payments

Create a product with a one-time and a monthly price, then build an invoice: add the customer and items, tax, a due date and payment settings, send it by email and SMS, and record a payment.

Chapters:
0:00 Intro
0:10 Why products first
0:26 Create a product
0:37 A one-time price
1:00 Save the product
1:20 Customer & items
1:34 Tax
1:50 Due date & payment settings
2:04 Send by email & SMS
2:15 Record a payment
2:29 Pro tip

◀ Previous: Lesson 62 · Connecting Stripe
▶ Next: Lesson 64 · Payment Links & Text2Pay
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Invoices #Products #Payments
```

### 12.3 · Payment links, Text2Pay & order forms (2:54)

**Title:** Lesson 64/75 · Payment Links & Text2Pay | Kyntlo Course – Module 12: Payments

**Description:**

```
📚 Kyntlo Course · Lesson 64 of 75 · Module 12 of 15: Payments

Get paid faster: create a reusable payment link, text a one-off payment request with Text2Pay, and understand how funnel order forms feed your Orders and Transactions.

Chapters:
0:00 Intro
0:13 Payment links
0:26 Create a payment link
0:36 Checkout options
0:51 Share your link
1:06 Text2Pay
1:24 Send a Text2Pay request
1:38 Track it like an invoice
1:49 Order forms
2:02 Upsells & order bumps
2:16 Every payment in one place
2:28 Pro tip

◀ Previous: Lesson 63 · Products, Prices & Invoices
▶ Next: Lesson 65 · Subscriptions & Transactions
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Paymentlinks #Text2Pay #Orderforms
```

### 12.4 · Subscriptions & transactions (3:04)

**Title:** Lesson 65/75 · Subscriptions & Transactions | Kyntlo Course – Module 12: Payments

**Description:**

```
📚 Kyntlo Course · Lesson 65 of 75 · Module 12 of 15: Payments

Manage recurring revenue: read your subscriptions and their statuses, recover past-due payments, cancel a subscription the right way, find any payment in Transactions and issue a full or partial refund.

Chapters:
0:00 Intro
0:14 Your subscriptions
0:25 Where they come from
0:39 Subscription statuses
0:53 Rescue a failed payment
1:07 Cancel a subscription
1:20 Transactions
1:34 Payment details
1:46 Issue a partial refund
1:58 After a refund
2:12 Full refunds
2:22 Failed payments & exports
2:35 Pro tip

◀ Previous: Lesson 64 · Payment Links & Text2Pay
▶ Next: Lesson 66 · Creating a Course
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Subscriptions #Refunds #Recurringrevenue
```

## Playlist: Kyntlo Academy · Module 13 — Memberships & Courses

### 13.1 · Creating a course (2:55)

**Title:** Lesson 66/75 · Creating a Course | Kyntlo Course – Module 13: Memberships

**Description:**

```
📚 Kyntlo Course · Lesson 66 of 75 · Module 13 of 15: Memberships

Build an online course in Kyntlo Memberships: create a product, organise it into categories, add a video lesson with notes and downloads, publish it and preview it as a member.

Chapters:
0:00 Intro
0:16 Courses in Kyntlo
0:32 Why a course
0:52 Create a product
1:09 Categories
1:26 Video
1:36 Lesson text
1:48 Downloads
2:07 Save
2:30 Pro tip

◀ Previous: Lesson 65 · Subscriptions & Transactions
▶ Next: Lesson 67 · Selling Course Access
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Memberships #Onlinecourse #Coursebuilder
```

### 13.2 · Selling access (2:52)

**Title:** Lesson 67/75 · Selling Course Access | Kyntlo Course – Module 13: Memberships

**Description:**

```
📚 Kyntlo Course · Lesson 67 of 75 · Module 13 of 15: Memberships

Sell your Kyntlo courses with offers: bundle products, set a free, one-time, subscription or payment-plan price, share the checkout link, and let buyers be enrolled automatically.

Chapters:
0:00 Intro
0:11 Offers explained
0:38 Create an offer
0:48 What's included
1:12 Automatic access
1:28 Publish
1:52 Test the checkout
2:03 Automatic enrolment
2:31 Pro tip

◀ Previous: Lesson 66 · Creating a Course
▶ Next: Lesson 68 · Communities
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Memberships #Sellonlinecourses #Membershipsite
```

### 13.3 · Communities (2:51)

**Title:** Lesson 68/75 · Communities | Kyntlo Course – Module 13: Memberships

**Description:**

```
📚 Kyntlo Course · Lesson 68 of 75 · Module 13 of 15: Memberships

Create a private community in Kyntlo Memberships: groups, channels, posts, linked courses, the leaderboard and inviting members.

Chapters:
0:00 Intro
0:13 Groups
0:28 Create a group
0:51 Inside a group
1:02 Sections & channels
1:24 Add a channel
1:46 Learning
1:57 Leaderboard
2:12 Invite members
2:22 Pro tip

◀ Previous: Lesson 67 · Selling Course Access
▶ Next: Lesson 69 · Phone Numbers & Caller ID
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Memberships #Onlinecommunity #Communities
```

## Playlist: Kyntlo Academy · Module 14 — Settings & Integrations

### 14.1 · Phone numbers & caller ID (3:12)

**Title:** Lesson 69/75 · Phone Numbers & Caller ID | Kyntlo Course – Module 14: Settings

**Description:**

```
📚 Kyntlo Course · Lesson 69 of 75 · Module 14 of 15: Settings

Buy a business phone number, choose between local and mobile numbers, set up call forwarding and caller ID, pick your default outbound number, and understand the Trust Center: regulatory bundles, A2P 10DLC and number porting.

Chapters:
0:00 Intro
0:14 Why a business number
0:29 Number types
0:47 Buy a number
1:13 Call forwarding & caller ID
1:48 Default outbound number
2:01 Trust Center
2:20 A2P 10DLC
2:38 Number porting
2:48 Pro tip

◀ Previous: Lesson 68 · Communities
▶ Next: Lesson 70 · Email Sending Domain
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Phonenumbers #A2P10DLC #Callforwarding #Settings
```

### 14.2 · Email services & sending domain (2:53)

**Title:** Lesson 70/75 · Email Sending Domain | Kyntlo Course – Module 14: Settings

**Description:**

```
📚 Kyntlo Course · Lesson 70 of 75 · Module 14 of 15: Settings

Set up a dedicated sending domain in Kyntlo: add a subdomain, copy the SPF, DKIM, MX, tracking and DMARC records to your DNS provider, verify the domain, and turn on email verification.

Chapters:
0:00 Intro
0:29 Add your domain
0:44 DNS records
1:01 SPF & DKIM
1:16 MX, tracking & DMARC
1:33 Add records automatically
1:43 Verify
1:59 Your sending domain
2:16 Email verification
2:29 Pro tip

◀ Previous: Lesson 69 · Phone Numbers & Caller ID
▶ Next: Lesson 71 · Integrations & App Marketplace
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Emaildeliverability #SPF #DKIM #DMARC #Settings
```

### 14.3 · Integrations & App Marketplace (2:58)

**Title:** Lesson 71/75 · Integrations & App Marketplace | Kyntlo Course – Module 14: Settings

**Description:**

```
📚 Kyntlo Course · Lesson 71 of 75 · Module 14 of 15: Settings

Connect Google, Facebook & Instagram and Zoom from Settings → Integrations, see where Stripe lives, and install extra apps like Slack from the App Marketplace.

Chapters:
0:00 Intro
0:10 Integrations
0:29 Google
0:58 Zoom
1:12 Manage & disconnect
1:30 Stripe
1:45 App Marketplace
2:01 Install an app
2:22 Installed apps
2:36 Pro tip

◀ Previous: Lesson 70 · Email Sending Domain
▶ Next: Lesson 72 · Usage, Wallet & Billing
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Integrations #AppMarketplace #GoogleBusinessProfile #Zoom
```

### 14.4 · Usage, wallet & billing (2:48)

**Title:** Lesson 72/75 · Usage, Wallet & Billing | Kyntlo Course – Module 14: Settings

**Description:**

```
📚 Kyntlo Course · Lesson 72 of 75 · Module 14 of 15: Settings

Understand how Kyntlo billing works: your plan subscription, your wallet balance, the usage summary at wholesale rates (email, SMS, calls, AI), adding balance, auto recharge, transactions and invoices.

Chapters:
0:00 Intro
0:11 Your plan
0:27 Your wallet
0:41 Usage summary
0:56 Email & SMS
1:17 Calls & AI
1:37 Add balance
1:50 Auto recharge
2:07 Transactions & invoices
2:23 Pro tip

◀ Previous: Lesson 71 · Integrations & App Marketplace
▶ Next: Lesson 73 · Data, Privacy & DND
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Billing #Wallet #Wholesalerates #Settings
```

### 14.5 · Data, privacy & DND (3:05)

**Title:** Lesson 73/75 · Data, Privacy & DND | Kyntlo Course – Module 14: Settings

**Description:**

```
📚 Kyntlo Course · Lesson 73 of 75 · Module 14 of 15: Settings

Respect consent in Kyntlo: use Do Not Disturb per channel, understand automatic opt-outs (STOP replies and unsubscribes), record marketing consent with a custom field, export a contact's data, restore deleted contacts and check the audit log.

Chapters:
0:00 Intro
0:11 Why consent matters
0:32 Do Not Disturb
1:08 Automatic opt-outs
1:26 Record consent
1:47 Data requests
1:58 Deleting data
2:11 Audit logs
2:25 Limit access
2:39 Pro tip

◀ Previous: Lesson 72 · Usage, Wallet & Billing
▶ Next: Lesson 74 · Build a Lead-to-Booking System
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #GDPR #DoNotDisturb #Consent #Dataprivacy
```

## Playlist: Kyntlo Academy · Module 15 — Capstone

### 15.1 · Build a complete lead-to-booking system (3:15)

**Title:** Lesson 74/75 · Build a Lead-to-Booking System | Kyntlo Course – Module 15: Capstone

**Description:**

```
📚 Kyntlo Course · Lesson 74 of 75 · Module 15 of 15: Capstone

Put the whole course together: follow one lead from your funnel and form, through an instant-reply workflow and your pipeline, to a booked appointment, reminders and a review request.

Chapters:
0:00 Intro
0:16 The system
0:35 1. The funnel
0:49 2. The form
1:02 3. The instant-reply workflow
1:16 4. The pipeline
1:31 5. The calendar
1:42 6. Confirmations & reminders
1:58 7. The review request
2:09 8. Reputation
2:22 Test it end to end
2:37 Measure it
2:49 Pro tip

◀ Previous: Lesson 73 · Data, Privacy & DND
▶ Next: Lesson 75 · Your 30-Day Action Plan
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Capstone #Leadtobooking #Marketingautomation
```

### 15.2 · Your 30-day Kyntlo action plan (2:54)

**Title:** Lesson 75/75 · Your 30-Day Action Plan | Kyntlo Course – Module 15: Capstone

**Description:**

```
📚 Kyntlo Course · Lesson 75 of 75 · Module 15 of 15: Capstone

Know exactly what to set up, and in which order: a four-week plan covering foundations, lead capture, automated follow-up and growth, plus the weekly habits that keep Kyntlo working for you.

Chapters:
0:00 Intro
0:13 The plan
0:29 Week 1 · Foundations
0:47 Bring in your contacts
1:00 Week 2 · Capture
1:21 Week 3 · Follow-up
1:44 Week 4 · Grow
2:07 Weekly habits
2:21 Pro tip

◀ Previous: Lesson 74 · Build a Lead-to-Booking System
🎉 That's the last lesson. You've finished the course!
🎓 Watch the whole course in order: https://www.youtube.com/@kyntlo/playlists

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Actionplan #Gettingstarted #CRMsetup
```

## Playlist: Kyntlo — Product Videos (public)

The course trailer (`b00`) goes on the course page and channel trailer; the rest are short public product videos.

### Kyntlo Course Trailer: 75 Free Lessons in 15 Modules (Start Here) (1:13)

**Description:**

```
Everything you will learn in Kyntlo Academy: 15 modules that take you from your first login to a complete lead-to-booking system. CRM, inbox, calendars, pipelines, funnels, marketing, automation, AI agents, reviews, payments, memberships and more.

Chapters:
0:00 Welcome
0:09 Modules 1–3
0:16 Modules 4–5
0:22 Modules 6–7
0:28 Modules 8–9
0:34 Modules 10–11
0:41 Modules 12–14
0:48 Module 15
0:55 How it works
1:04 Start with lesson 1

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #KyntloAcademy #Kyntlocourse #CRMtraining #Marketingautomationcourse
```

### Kyntlo in 90 Seconds — Your Whole Business in One Platform (1:18)

**Description:**

```
See how Kyntlo brings your CRM, inbox, online booking, sales pipeline, funnels, automation, AI agents and reviews together in one platform, with one login and one invoice. Start your free 14-day trial at kyntlo.ai.

Chapters:
0:00 Intro
0:06 Dashboard
0:17 One inbox
0:27 Online booking
0:32 Sales pipeline
0:36 Automation
0:43 Funnels & websites
0:49 AI agents
0:56 Reviews
1:03 One invoice
1:10 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #CRM #MarketingAutomation #SmallBusiness #AI #All-in-oneCRM
```

### Replace a $2,488+/mo Tool Stack with One Platform — Kyntlo (1:48)

**Description:**

```
CRM, funnels, website, forms, email, SMS, booking, automation and reviews: see what Kyntlo replaces, what a typical stack of separate tools costs, and how one platform with one invoice compares.

Chapters:
0:00 Intro
0:10 A typical stack
0:25 Nine tools, nine bills
0:35 What it costs
0:44 One platform
0:55 One CRM
1:01 Funnels & forms
1:08 No more glue
1:16 What Kyntlo costs
1:26 Usage & plans
1:40 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Softwarestack #CRMpricing #All-in-oneCRM #Smallbusinesstools #HubSpotalternative
```

### Never Miss a Lead Again — One Inbox + Missed-Call Text-Back | Kyntlo (1:16)

**Description:**

```
Every text, email, WhatsApp, Facebook, Instagram and website chat in one inbox, plus missed-call text-back that texts callers back within seconds, so a missed call becomes a conversation instead of a lost customer.

Chapters:
0:00 Intro
0:06 One inbox
0:17 One thread per customer
0:25 Teamwork
0:34 The missed call problem
0:43 Missed-call text-back
0:51 From missed call to booking
1:01 Which plan?
1:08 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Missedcalltextback #Unifiedinbox #Leadfollow-up #SmallbusinessCRM
```

### Bookings on Autopilot — Online Booking, Reminders & No-Show Recovery | Kyntlo (1:17)

**Description:**

```
Let customers book themselves online, send automatic email and text reminders, and win back no-shows with a friendly rebooking workflow, all in Kyntlo.

Chapters:
0:00 Intro
0:08 Your calendar
0:15 Online booking
0:27 Automatic reminders
0:35 Set your timing
0:44 When someone no-shows
0:50 No-show recovery
1:02 Which plan?
1:09 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Onlinebooking #Appointmentreminders #Reduceno-shows #Schedulingsoftware
```

### Your AI Employee — AI Chatbot & AI Phone Receptionist | Kyntlo (1:43)

**Description:**

```
Meet Conversation AI and Voice AI: a chatbot that answers your messages and books appointments, and an AI receptionist that answers your phone, routes urgent calls and logs every conversation.

Chapters:
0:00 Intro
0:09 Conversation AI
0:21 Teach it your business
0:30 It answers questions
0:39 It books appointments
0:48 Voice AI
0:55 Meet Rosie
1:05 What she can do
1:15 Every call logged
1:23 Which plan?
1:34 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #AIchatbot #AIreceptionist #VoiceAI #ConversationAI #AIforsmallbusiness
```

### Build a Funnel in Minutes — From Template to Live Page | Kyntlo (1:34)

**Description:**

```
Pick a ready-made funnel template, add your business name, headline, colours and photo, publish it, and track views and opt-ins, without a designer or developer.

Chapters:
0:00 Intro
0:08 New funnel
0:16 Pick a template
0:26 Preview & create
0:36 Three steps, instantly
0:43 Make it yours
0:50 Colours & photos
0:56 Publish
1:01 Share it
1:10 See what works
1:19 Every plan
1:25 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Funnelbuilder #Landingpagebuilder #Salesfunnel #Leadgeneration
```

### Five-Star Reviews on Repeat — Automatic Review Requests & AI Replies | Kyntlo (1:12)

**Description:**

```
Ask every customer for a review automatically after their visit, track who reviewed, reply in seconds with Reviews AI, and show your best reviews on your website.

Chapters:
0:00 Intro
0:11 Your reputation
0:22 Ask automatically
0:33 Track every request
0:41 Reply with AI
0:50 Show them off
0:56 Which plan?
1:03 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Googlereviews #Reviewmanagement #Reputationmanagement #Reviewrequests
```

### Which Kyntlo Plan Is Right for You? Starter vs Growth vs Pro vs Customized (2:27)

**Description:**

```
Compare Kyntlo's four plans: what's included in Starter, Growth, Pro and Customized, how quarterly billing halves your first three months, how usage is billed at wholesale cost, and how to choose. Every plan starts with a 14-day free trial.

Chapters:
0:00 Intro
0:09 Four plans
0:17 Starter
0:34 Growth
0:51 Pro
1:13 Customized
1:28 Quarterly billing
1:43 Usage at wholesale cost
1:56 How to choose
2:08 Free trial
2:20 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Kyntlopricing #Kyntloplans #CRMpricing #StartervsGrowthvsPro
```

### Kyntlo for Clinics — Bookings, Reminders, AI Reception & Reviews in One Platform (1:41)

**Description:**

```
How a clinic runs on Kyntlo: patient records, online booking, automatic reminders, no-show recovery, missed-call text-back, an AI phone receptionist, review requests and recall campaigns, shown on a demo dental practice.

Chapters:
0:00 Intro
0:10 Meet Bloom Dental
0:19 Every patient, one record
0:26 Online booking
0:35 Reminders & no-shows
0:49 Missed-call text-back
1:00 AI receptionist
1:10 Reviews
1:17 Recall patients
1:22 Which plan?
1:34 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Clinicsoftware #Dentalpracticemarketing #Patientbooking #ClinicCRM #Healthcaremarketing
```

### Kyntlo for Salons — Online Booking, Reminders, Reviews & Rebooking on Autopilot (1:41)

**Description:**

```
How salons, barbers, spas and beauty studios can use Kyntlo: online booking by stylist, automatic reminders, one inbox for Instagram, Facebook, WhatsApp and text, an AI chatbot that books, review requests and automatic rebooking offers.

Chapters:
0:00 Intro
0:09 Same tools, your salon
0:19 Online booking
0:30 Every stylist, one diary
0:39 Fewer no-shows
0:47 One inbox
0:56 AI that books
1:06 Reviews
1:13 Bring clients back
1:20 Which plan?
1:34 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Salonsoftware #Salonbooking #Beautysalonmarketing #Barbershopbooking #SpaCRM
```

### Kyntlo for Agencies — Funnels, Pipelines, Automation & Reporting in One Platform (1:32)

**Description:**

```
How marketing agencies and consultants can run on Kyntlo: launch funnels from templates, track every lead in a pipeline, automate follow-up, send email and SMS campaigns, see which ads bring in leads, and use Content AI, with a Customized plan for multiple brands.

Chapters:
0:00 Intro
0:11 Same tools, your agency
0:21 Funnels in minutes
0:30 Every lead in the pipeline
0:36 Automated follow-up
0:45 Campaigns
0:52 Reporting
0:59 Content AI
1:08 Built around you
1:24 Start your free trial

Start your free 14-day Kyntlo trial: https://kyntlo.ai/trial

#Kyntlo #Marketingagencysoftware #AgencyCRM #Funnelbuilder #Marketingautomation #Leadgenerationagency
```
